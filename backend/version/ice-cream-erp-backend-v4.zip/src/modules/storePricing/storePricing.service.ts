import { prisma } from '../../lib/prisma';
import { logAudit } from '../../lib/audit';
import { numOrUndefined } from '../../utils/serialize';
import { ApiError } from '../../utils/ApiError';

function serialize(row: { id: string; store_id: string; product_id: string; wholesale_discount_pct: any; retail_discount_pct: any }) {
  return {
    id: row.id,
    store_id: row.store_id,
    product_id: row.product_id,
    wholesale_discount_pct: numOrUndefined(row.wholesale_discount_pct),
    retail_discount_pct: numOrUndefined(row.retail_discount_pct),
  };
}

export async function listStorePricing() {
  const rows = await prisma.storePricing.findMany();
  return rows.map(serialize);
}

interface UpsertInput {
  store_id: string;
  product_id: string;
  wholesale_discount_pct: number | null;
  retail_discount_pct: number | null;
}

// A row with both sides null means "no override for either rate" - i.e.
// nothing left to track - so it's deleted instead of stored empty. Either
// field left null (not zero) keeps that side following the catalog's live
// rate rather than freezing today's value.
export async function upsertStorePricing(input: UpsertInput, actorId: string) {
  const store = await prisma.store.findUnique({ where: { id: input.store_id } });
  if (!store) throw ApiError.notFound('Store not found.');
  const product = await prisma.product.findUnique({ where: { id: input.product_id } });
  if (!product) throw ApiError.notFound('Product not found.');

  if (input.wholesale_discount_pct === null && input.retail_discount_pct === null) {
    await prisma.storePricing.deleteMany({ where: { store_id: input.store_id, product_id: input.product_id } });
    await logAudit({ action: 'STORE_PRICING_RESET', entity_type: 'Store', entity_id: input.store_id, user_id: actorId, details: `Reset ${product.name} back to catalog pricing for ${store.name}` });
    return null;
  }

  const row = await prisma.storePricing.upsert({
    where: { store_id_product_id: { store_id: input.store_id, product_id: input.product_id } },
    update: { wholesale_discount_pct: input.wholesale_discount_pct, retail_discount_pct: input.retail_discount_pct },
    create: {
      store_id: input.store_id,
      product_id: input.product_id,
      wholesale_discount_pct: input.wholesale_discount_pct,
      retail_discount_pct: input.retail_discount_pct,
    },
  });

  await logAudit({ action: 'STORE_PRICING_SET', entity_type: 'Store', entity_id: input.store_id, user_id: actorId, details: `Set custom pricing for ${product.name} at ${store.name}` });
  return serialize(row);
}

export async function removeStorePricing(id: string, actorId: string) {
  const row = await prisma.storePricing.findUnique({ where: { id }, include: { store: true, product: true } });
  if (!row) throw ApiError.notFound('Custom pricing entry not found.');

  await prisma.storePricing.delete({ where: { id } });
  await logAudit({ action: 'STORE_PRICING_RESET', entity_type: 'Store', entity_id: row.store_id, user_id: actorId, details: `Reset ${row.product.name} back to catalog pricing for ${row.store.name}` });
  return { id };
}
