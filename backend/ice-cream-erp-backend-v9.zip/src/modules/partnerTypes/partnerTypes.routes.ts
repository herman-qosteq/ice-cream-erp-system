import { Router } from 'express';
import { asyncHandler } from '../../middleware/asyncHandler';
import { requireAuth, requireRole } from '../../middleware/auth';
import * as partnerTypesController from './partnerTypes.controller';

export const partnerTypesRouter = Router();

partnerTypesRouter.get('/', requireAuth, asyncHandler(partnerTypesController.list));
partnerTypesRouter.post('/', requireAuth, requireRole('Admin'), asyncHandler(partnerTypesController.create));
partnerTypesRouter.patch('/:id', requireAuth, requireRole('Admin'), asyncHandler(partnerTypesController.rename));
partnerTypesRouter.delete('/:id', requireAuth, requireRole('Admin'), asyncHandler(partnerTypesController.remove));
