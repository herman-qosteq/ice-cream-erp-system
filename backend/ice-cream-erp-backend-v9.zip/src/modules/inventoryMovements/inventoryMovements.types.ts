import { StockLocationType } from '@prisma/client';

export interface MoveStockInput {
  from_type: StockLocationType;
  from_id?: string | null;
  to_type: StockLocationType;
  to_id?: string | null;
  product_id: string;
  qty: number;
  reason?: string;
}
