import { Router } from 'express';
import { asyncHandler } from '../../middleware/asyncHandler';
import { requireAuth, requireRole } from '../../middleware/auth';
import * as inventoryMovementsController from './inventoryMovements.controller';

export const inventoryMovementsRouter = Router();

inventoryMovementsRouter.get('/', requireAuth, asyncHandler(inventoryMovementsController.list));
inventoryMovementsRouter.post('/move', requireAuth, requireRole('Admin', 'Warehouse'), asyncHandler(inventoryMovementsController.move));
