import { Router } from 'express';
import { asyncHandler } from '../../middleware/asyncHandler';
import { requireAuth, requireRole } from '../../middleware/auth';
import * as assetsController from './assets.controller';

export const assetsRouter = Router();

assetsRouter.get('/', requireAuth, asyncHandler(assetsController.list));
assetsRouter.get('/inventory-summary', requireAuth, asyncHandler(assetsController.inventorySummary));
assetsRouter.get('/inventory', requireAuth, asyncHandler(assetsController.allInventory));
assetsRouter.get('/history', requireAuth, asyncHandler(assetsController.allHistory));
assetsRouter.post('/', requireAuth, requireRole('Admin'), asyncHandler(assetsController.create));
assetsRouter.patch('/:id', requireAuth, requireRole('Admin'), asyncHandler(assetsController.update));
assetsRouter.post('/:id/assign', requireAuth, requireRole('Admin', 'Warehouse'), asyncHandler(assetsController.assign));
assetsRouter.post('/:id/return', requireAuth, requireRole('Admin', 'Warehouse'), asyncHandler(assetsController.returnAsset));
assetsRouter.post('/:id/maintenance-start', requireAuth, requireRole('Admin', 'Warehouse'), asyncHandler(assetsController.maintenanceStart));
assetsRouter.post('/:id/maintenance-end', requireAuth, requireRole('Admin', 'Warehouse'), asyncHandler(assetsController.maintenanceEnd));
assetsRouter.post('/:id/mark-lost', requireAuth, requireRole('Admin', 'Warehouse'), asyncHandler(assetsController.markLost));
assetsRouter.post('/:id/reactivate', requireAuth, requireRole('Admin'), asyncHandler(assetsController.reactivate));
assetsRouter.post('/:id/deactivate', requireAuth, requireRole('Admin'), asyncHandler(assetsController.deactivate));
assetsRouter.get('/:id/history', requireAuth, asyncHandler(assetsController.history));
assetsRouter.get('/:id/inventory', requireAuth, asyncHandler(assetsController.inventory));
