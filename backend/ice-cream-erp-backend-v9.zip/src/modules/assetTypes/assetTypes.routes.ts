import { Router } from 'express';
import { asyncHandler } from '../../middleware/asyncHandler';
import { requireAuth, requireRole } from '../../middleware/auth';
import * as assetTypesController from './assetTypes.controller';

export const assetTypesRouter = Router();

assetTypesRouter.get('/', requireAuth, asyncHandler(assetTypesController.list));
assetTypesRouter.post('/', requireAuth, requireRole('Admin'), asyncHandler(assetTypesController.create));
assetTypesRouter.patch('/:id', requireAuth, requireRole('Admin'), asyncHandler(assetTypesController.rename));
assetTypesRouter.delete('/:id', requireAuth, requireRole('Admin'), asyncHandler(assetTypesController.remove));
